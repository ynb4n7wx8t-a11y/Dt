const APP_CACHE_NAME = 'fcalendar-app-v6';
const MAP_TILE_CACHE_NAME = 'fcalendar-map-tiles-v1';
const MAP_TILE_CACHE_LIMIT = 1200;
const MAP_TILE_TRIM_INTERVAL = 40;

let mapTileWriteCount = 0;
let mapTileTrimInFlight = false;

// In Vite dev mode the SW should be a transparent passthrough — caching dev
// assets causes "text/html is not a valid JS MIME type" errors when a stale
// HTML page is returned for a JS module request.
const IS_DEV = self.location.hostname === 'localhost' ||
               self.location.hostname === '127.0.0.1' ||
               self.location.port !== '';

const PRECACHE_URLS = [
  '/manifest.json',
  '/FamilyMart.png',
  '/icon.svg'
];

self.addEventListener('install', (event) => {
  // Skip precaching in dev; go active immediately.
  if (IS_DEV) { self.skipWaiting(); return; }
  event.waitUntil(
    caches.open(APP_CACHE_NAME)
      .then((cache) => cache.addAll(PRECACHE_URLS))
      .catch(() => {})
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) =>
      Promise.all(
        cacheNames.map((name) => {
          if (name !== APP_CACHE_NAME && name !== MAP_TILE_CACHE_NAME) return caches.delete(name);
        })
      )
    )
  );
  self.clients.claim();
});

function isMapTileRequest(requestUrl) {
  return /(^|\.)tile\.openstreetmap\.org$/i.test(requestUrl.hostname);
}

function isScriptOrStyle(url) {
  return /\.(js|mjs|ts|tsx|css)(\?|$)/.test(url.pathname) ||
         url.pathname.startsWith('/@') ||
         url.pathname.startsWith('/src/') ||
         url.pathname.startsWith('/node_modules/');
}

async function trimCache(cacheName, maxEntries) {
  const cache = await caches.open(cacheName);
  const keys = await cache.keys();
  if (keys.length <= maxEntries) return;
  const deleteCount = keys.length - maxEntries;
  for (let i = 0; i < deleteCount; i += 1) {
    await cache.delete(keys[i]);
  }
}

async function maybeTrimMapTileCache() {
  if (mapTileTrimInFlight) return;
  if (mapTileWriteCount % MAP_TILE_TRIM_INTERVAL !== 0) return;
  mapTileTrimInFlight = true;
  try {
    await trimCache(MAP_TILE_CACHE_NAME, MAP_TILE_CACHE_LIMIT);
  } finally {
    mapTileTrimInFlight = false;
  }
}

async function cacheMapTile(request, responseForCache) {
  const cache = await caches.open(MAP_TILE_CACHE_NAME);
  await cache.put(request, responseForCache);
  mapTileWriteCount += 1;
  await maybeTrimMapTileCache();
}

self.addEventListener('fetch', (event) => {
  // Dev mode: full passthrough — never interfere with Vite HMR or modules.
  if (IS_DEV) return;

  const url = new URL(event.request.url);

  // OSM tiles — stale-while-revalidate
  if (event.request.method === 'GET' && isMapTileRequest(url)) {
    event.respondWith(
      caches.open(MAP_TILE_CACHE_NAME).then(async (cache) => {
        const cached = await cache.match(event.request);
        const networkPromise = fetch(event.request)
          .then(async (response) => {
            const canCache = response && (response.ok || response.type === 'opaque');
            if (canCache) event.waitUntil(cacheMapTile(event.request, response.clone()));
            return response;
          })
          .catch(() => null);
        if (cached) { event.waitUntil(networkPromise); return cached; }
        const networkResponse = await networkPromise;
        if (networkResponse) return networkResponse;
        return new Response('', { status: 504, statusText: 'Map tile unavailable' });
      })
    );
    return;
  }

  // API calls — always network, never cache
  if (url.pathname.startsWith('/api/')) {
    event.respondWith(fetch(event.request));
    return;
  }

  // JS/CSS/module files — network first; on failure return cached version ONLY
  // if it was a real script (never fall back to HTML for script requests).
  if (isScriptOrStyle(url)) {
    event.respondWith(
      fetch(event.request).then((response) => {
        if (response && response.status === 200 && response.type === 'basic') {
          const clone = response.clone();
          caches.open(APP_CACHE_NAME).then((cache) => cache.put(event.request, clone));
        }
        return response;
      }).catch(async () => {
        const cached = await caches.match(event.request);
        // Only return cached if it looks like a script/style (not HTML fallback)
        if (cached) {
          const ct = cached.headers.get('content-type') ?? '';
          if (!ct.includes('text/html')) return cached;
        }
        return new Response('/* offline */', { status: 503, headers: { 'content-type': 'application/javascript' } });
      })
    );
    return;
  }

  // HTML navigation — network first, offline fallback to cached shell
  if (event.request.mode === 'navigate' || event.request.headers.get('accept')?.includes('text/html')) {
    event.respondWith(
      fetch(event.request).catch(() => caches.match('/index.html'))
    );
    return;
  }

  // Hashed assets (/assets/...) — cache first
  if (url.pathname.startsWith('/assets/')) {
    event.respondWith(
      caches.match(event.request).then((cached) => {
        if (cached) return cached;
        return fetch(event.request).then((response) => {
          if (response && response.status === 200 && response.type === 'basic') {
            const clone = response.clone();
            caches.open(APP_CACHE_NAME).then((cache) => cache.put(event.request, clone));
          }
          return response;
        });
      })
    );
    return;
  }

  // Everything else — network first, safe cache fallback (skip HTML-as-script)
  event.respondWith(
    fetch(event.request)
      .then((response) => {
        if (response && response.status === 200 && response.type === 'basic') {
          const clone = response.clone();
          caches.open(APP_CACHE_NAME).then((cache) => cache.put(event.request, clone));
        }
        return response;
      })
      .catch(async () => {
        const cached = await caches.match(event.request);
        return cached ?? new Response('', { status: 503 });
      })
  );
});

self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});
